import tkinter as tk
import time
import threading
import itertools

# --- 偽アクティベーション処理 ---
def fake_antipiracy():
    root = tk.Tk()
    root.attributes("-fullscreen", True)
    root.configure(bg="black")
    root.title("Windows 非正規コピー検出")

    label = tk.Label(root, text="⚠ このコピーのWindowsは正規品ではありません", fg="red", bg="black", font=("Arial", 24, "bold"))
    label.pack(pady=40)

    status = tk.Label(root, text="Microsoftに送信しています...", fg="cyan", bg="black", font=("Arial", 18))
    status.pack(pady=10)

    progress = tk.Label(root, text="[■□□□□□□□□□] 10%", fg="green", bg="black", font=("Courier", 18))
    progress.pack(pady=10)

    loader_label = tk.Label(root, text="", fg="white", bg="black", font=("Courier", 14))
    loader_label.pack(pady=10)

    result = tk.Label(root, text="", fg="yellow", bg="black", font=("Arial", 18))
    result.pack(pady=30)

    def update_loader():
        for frame in itertools.cycle(["📶", "📶.", "📶..", "📶..."]):
            loader_label.config(text=f"ネットワーク接続中 {frame}")
            time.sleep(0.5)

    def update_process():
        steps = [
            ("[■■■□□□□□□□] 30%", "送信中..."),
            ("[■■■■■□□□□□] 50%", "送信中..."),
            ("[■■■■■■■□□□] 70%", "エラー：送信に失敗しました"),
            ("[■■■■■■■■■□] 90%", "国際接続を開始しています..."),
            ("[■■■■■■■■■■] 100%", "完了しました！（偽）"),
        ]
        for bar, msg in steps:
            time.sleep(2)
            progress.config(text=bar)
            status.config(text=msg)
            root.update()

        time.sleep(2)
        loader_label.config(text="")
        result.config(text="Microsoftは偉大です。\nでもこれはジョークです。\n安心してね😉", fg="lightgreen")
        root.configure(bg="#0033cc")
        root.after(4000, lambda: show_activation_ui(root))

    threading.Thread(target=update_loader, daemon=True).start()
    threading.Thread(target=update_process, daemon=True).start()

    root.protocol("WM_DELETE_WINDOW", lambda: None)
    root.mainloop()

# --- 偽アクティベーション画面 ---
def show_activation_ui(old_root):
    old_root.destroy()
    root = tk.Tk()
    root.attributes("-fullscreen", True)
    root.configure(bg="black")
    root.title("Microsoft アクティベーション（偽）")

    label = tk.Label(root, text="💳 プロダクトキーを入力してください", fg="white", bg="black", font=("Arial", 20, "bold"))
    label.pack(pady=30)

    entry = tk.Entry(root, font=("Courier", 16), width=30, justify='center')
    entry.pack(pady=10)

    message = tk.Label(root, text="", fg="red", bg="black", font=("Arial", 16))
    message.pack(pady=10)

    def validate_key():
        key = entry.get()
        if len(key) == 29 and all(c.isalnum() or c == '-' for c in key):
            message.config(text="そのプロダクトキーは存在しません")
            root.after(2000, lambda: show_confession_ui(root))
        else:
            message.config(text="形式が正しくありません（XXXXX-XXXXX-XXXXX-XXXXX-XXXXX）")

    submit_btn = tk.Button(root, text="認証する", command=validate_key, font=("Arial", 16), bg="gray20", fg="white")
    submit_btn.pack(pady=20)

    root.protocol("WM_DELETE_WINDOW", lambda: None)
    root.mainloop()

# --- 偽反省文画面 ---
def show_confession_ui(old_root):
    old_root.destroy()
    root = tk.Tk()
    root.attributes("-fullscreen", True)
    root.configure(bg="black")
    root.title("反省文入力（偽）")

    tk.Label(root, text="📨 Microsoft への反省文を入力してください", fg="white", bg="black", font=("Arial", 20)).pack(pady=30)

    textbox = tk.Text(root, width=60, height=10, font=("Arial", 14))
    textbox.pack(pady=20)

    status = tk.Label(root, text="", fg="lime", bg="black", font=("Arial", 16))
    status.pack(pady=10)

    def fake_send():
        status.config(text="送信中...")
        root.update()
        time.sleep(3)
        status.config(text="送信されませんでした！これは全部ジョークです🤣")
        root.configure(bg="#222")
        root.after(4000, lambda: root.destroy())

    tk.Button(root, text="送信", command=fake_send, font=("Arial", 16), bg="green", fg="white").pack(pady=20)

    root.protocol("WM_DELETE_WINDOW", lambda: None)
    root.mainloop()

# --- 起動 ---
if __name__ == "__main__":
    fake_antipiracy()
